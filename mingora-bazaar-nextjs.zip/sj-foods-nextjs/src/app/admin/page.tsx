"use client";

import { useEffect, useState } from "react";
import {
  fetchAllVendors,
  fetchCategories,
  fetchVendorProducts,
  setVendorStatus,
  addCategory,
  deleteCategory,
  upsertProduct,
  deleteProduct,
  type Vendor,
  type Category,
  type Product,
} from "@/lib/firebase";

const ADMIN_PASSWORD = process.env.NEXT_PUBLIC_ADMIN_PASSWORD;

export default function AdminPage() {
  const [unlocked, setUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [tab, setTab] = useState<"vendors" | "categories" | "products">("vendors");

  if (!unlocked) {
    return (
      <div className="max-w-sm mx-auto px-6 mt-20">
        <h2 className="font-display text-xl font-bold mb-4">Admin login</h2>
        <input
          type="password"
          value={passwordInput}
          onChange={(e) => setPasswordInput(e.target.value)}
          placeholder="Password"
          className="w-full border border-stone rounded-lg px-3 py-2 mb-3"
        />
        <button
          className="btn-primary w-full"
          onClick={() => passwordInput === ADMIN_PASSWORD && setUnlocked(true)}
        >
          Login
        </button>
        {!ADMIN_PASSWORD && (
          <p className="text-terracotta text-sm mt-3">
            NEXT_PUBLIC_ADMIN_PASSWORD set nahi hai — .env.local mein add karein.
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      <h2 className="font-display text-2xl font-bold mb-6">Master Control Dashboard</h2>

      <div className="flex gap-2 mb-8">
        {(["vendors", "categories", "products"] as const).map((t) => (
          <button
            key={t}
            className={`category-tag ${tab === t ? "active" : ""}`}
            onClick={() => setTab(t)}
          >
            {t === "vendors" ? "Vendors" : t === "categories" ? "Categories" : "Pricing & Units"}
          </button>
        ))}
      </div>

      {tab === "vendors" && <VendorsPanel />}
      {tab === "categories" && <CategoriesPanel />}
      {tab === "products" && <ProductsPanel />}
    </div>
  );
}

/* ============================================================ */

function VendorsPanel() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);

  function reload() {
    fetchAllVendors().then((v) => {
      setVendors(v);
      setLoading(false);
    });
  }

  useEffect(reload, []);

  async function updateStatus(id: string, status: Vendor["status"]) {
    await setVendorStatus(id, status);
    reload();
  }

  if (loading) return <p className="text-stone">Load ho raha hai...</p>;

  return (
    <div className="space-y-3">
      {vendors.map((v) => (
        <div
          key={v.id}
          className="border border-stone rounded-lg p-4 flex items-center justify-between"
        >
          <div>
            <p className="font-semibold">{v.name}</p>
            <p className="text-sm text-stone">
              {v.category} · {v.area} · {v.phone}
            </p>
            <p
              className={`text-sm font-semibold ${
                v.status === "approved"
                  ? "text-pine"
                  : v.status === "rejected"
                  ? "text-terracotta"
                  : "text-marigold"
              }`}
            >
              {v.status}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              className="btn-primary text-sm py-1.5 px-3"
              onClick={() => updateStatus(v.id, "approved")}
            >
              Approve
            </button>
            <button
              className="text-sm py-1.5 px-3 border border-terracotta text-terracotta rounded-lg"
              onClick={() => updateStatus(v.id, "rejected")}
            >
              Reject
            </button>
          </div>
        </div>
      ))}
      {vendors.length === 0 && <p className="text-stone">Abhi koi vendor register nahi hua.</p>}
    </div>
  );
}

/* ============================================================ */

function CategoriesPanel() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("");

  function reload() {
    fetchCategories().then(setCategories);
  }

  useEffect(reload, []);

  async function handleAdd() {
    if (!name.trim()) return;
    await addCategory(name.trim(), icon.trim());
    setName("");
    setIcon("");
    reload();
  }

  async function handleDelete(id: string) {
    await deleteCategory(id);
    reload();
  }

  return (
    <div>
      <div className="flex gap-2 mb-6">
        <input
          value={icon}
          onChange={(e) => setIcon(e.target.value)}
          placeholder="Emoji"
          className="w-20 border border-stone rounded-lg px-3 py-2"
        />
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Category ka naam"
          className="flex-1 border border-stone rounded-lg px-3 py-2"
        />
        <button className="btn-primary" onClick={handleAdd}>
          Add
        </button>
      </div>

      <div className="space-y-2">
        {categories.map((c) => (
          <div
            key={c.id}
            className="flex items-center justify-between border border-stone rounded-lg px-4 py-2"
          >
            <span>
              {c.icon} {c.name}
            </span>
            <button
              className="text-terracotta text-sm"
              onClick={() => handleDelete(c.id)}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================ */

function ProductsPanel() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [selectedVendor, setSelectedVendor] = useState<string>("");
  const [products, setProducts] = useState<Product[]>([]);
  const [form, setForm] = useState({ name: "", price: "", unit: "kg", category: "", inStock: true });

  useEffect(() => {
    fetchAllVendors().then((v) => {
      setVendors(v.filter((x) => x.status === "approved"));
    });
  }, []);

  function reloadProducts(vendorId: string) {
    fetchVendorProducts(vendorId).then(setProducts);
  }

  function handleSelectVendor(id: string) {
    setSelectedVendor(id);
    reloadProducts(id);
  }

  async function handleSave() {
    if (!selectedVendor || !form.name.trim() || !form.price) return;
    await upsertProduct(selectedVendor, null, {
      name: form.name.trim(),
      price: Number(form.price),
      unit: form.unit,
      category: form.category.trim(),
      inStock: form.inStock,
    });
    setForm({ name: "", price: "", unit: "kg", category: "", inStock: true });
    reloadProducts(selectedVendor);
  }

  async function handleUpdatePrice(p: Product, price: number) {
    await upsertProduct(selectedVendor, p.id, { ...p, price });
    reloadProducts(selectedVendor);
  }

  async function handleToggleStock(p: Product) {
    await upsertProduct(selectedVendor, p.id, { ...p, inStock: !p.inStock });
    reloadProducts(selectedVendor);
  }

  async function handleDelete(productId: string) {
    await deleteProduct(selectedVendor, productId);
    reloadProducts(selectedVendor);
  }

  return (
    <div>
      <select
        value={selectedVendor}
        onChange={(e) => handleSelectVendor(e.target.value)}
        className="border border-stone rounded-lg px-3 py-2 mb-6"
      >
        <option value="">Vendor chunein...</option>
        {vendors.map((v) => (
          <option key={v.id} value={v.id}>
            {v.name}
          </option>
        ))}
      </select>

      {selectedVendor && (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-6">
            <input
              placeholder="Item name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="border border-stone rounded-lg px-3 py-2 col-span-2"
            />
            <input
              placeholder="Price"
              type="number"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="border border-stone rounded-lg px-3 py-2"
            />
            <select
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
              className="border border-stone rounded-lg px-3 py-2"
            >
              <option value="kg">kg</option>
              <option value="piece">piece</option>
              <option value="dozen">dozen</option>
              <option value="litre">litre</option>
              <option value="packet">packet</option>
            </select>
            <button className="btn-primary" onClick={handleSave}>
              Add item
            </button>
          </div>

          <div className="space-y-2">
            {products.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between border border-stone rounded-lg px-4 py-2 gap-3"
              >
                <span className="flex-1">{p.name}</span>
                <input
                  type="number"
                  defaultValue={p.price}
                  onBlur={(e) => handleUpdatePrice(p, Number(e.target.value))}
                  className="w-20 border border-stone rounded-lg px-2 py-1"
                />
                <span className="text-stone text-sm w-16">/ {p.unit}</span>
                <button
                  className={`text-sm ${p.inStock ? "text-pine" : "text-terracotta"}`}
                  onClick={() => handleToggleStock(p)}
                >
                  {p.inStock ? "In stock" : "Out of stock"}
                </button>
                <button className="text-terracotta text-sm" onClick={() => handleDelete(p.id)}>
                  Delete
                </button>
              </div>
            ))}
            {products.length === 0 && <p className="text-stone">Is vendor ke items abhi khali hain.</p>}
          </div>
        </>
      )}
    </div>
  );
}
