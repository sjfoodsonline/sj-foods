"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  fetchApprovedVendors,
  fetchCategories,
  type Vendor,
  type Category,
} from "@/lib/firebase";

function rotationFor(id: string) {
  const n = id.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  return (n % 5) - 2; // -2deg .. +2deg, so cards don't look like a uniform kit
}

export default function HomePage() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeCategory, setActiveCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([fetchApprovedVendors(), fetchCategories()]).then(
      ([v, c]) => {
        setVendors(v);
        setCategories(c);
        setLoading(false);
      }
    );
  }, []);

  const filtered = useMemo(() => {
    return vendors.filter((v) => {
      const inCategory = activeCategory === "all" || v.category === activeCategory;
      const inSearch = !query || v.name.toLowerCase().includes(query.toLowerCase());
      return inCategory && inSearch;
    });
  }, [vendors, activeCategory, query]);

  return (
    <>
      <section className="max-w-6xl mx-auto px-6 pt-8">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          type="text"
          placeholder="Dukaan ya item talash karein..."
          className="w-full md:w-96 border border-stone rounded-lg px-4 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-pine"
        />
        <div className="flex flex-wrap gap-2 mt-5">
          <button
            className={`category-tag ${activeCategory === "all" ? "active" : ""}`}
            onClick={() => setActiveCategory("all")}
          >
            Sab dukaanein
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              className={`category-tag ${activeCategory === cat.name ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.name)}
            >
              {cat.icon ? `${cat.icon} ` : ""}
              {cat.name}
            </button>
          ))}
        </div>
      </section>

      <main className="max-w-6xl mx-auto px-6 py-10">
        {loading && <p className="text-stone">Dukaanein load ho rahi hain...</p>}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((v) => (
            <Link
              key={v.id}
              href={`/vendor/${v.slug}`}
              className="signboard relative block p-5"
              style={{ transform: `rotate(${rotationFor(v.id)}deg)` }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-full bg-pine text-paper flex items-center justify-center font-display text-lg font-bold">
                  {v.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold leading-tight">
                    {v.name}
                  </h3>
                  <p className="text-sm text-stone">{v.area || "Mingora"}</p>
                </div>
              </div>
              <p className="text-sm opacity-80">
                {v.description || "Roz mara ki cheezein, achi quality."}
              </p>
              <span className="inline-block mt-4 text-sm font-semibold text-pine">
                Dukaan dekhein →
              </span>
            </Link>
          ))}
        </div>

        {!loading && filtered.length === 0 && (
          <p className="text-center text-stone mt-16">
            Abhi is category mein koi dukaan register nahi hui — jald aayegi.
          </p>
        )}
      </main>

      <footer className="text-center text-sm text-stone py-8">
        Mingora Bazaar · Naya vendor register karna hai? WhatsApp par owner se
        raabta karein.
      </footer>
    </>
  );
}
