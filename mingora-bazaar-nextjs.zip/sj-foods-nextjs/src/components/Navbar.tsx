import Link from "next/link";

export default function Navbar() {
  return (
    <header className="bazaar-header text-paper px-6 py-5">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <Link href="/">
          <h1 className="font-display text-2xl md:text-3xl font-bold">
            Mingora Bazaar
          </h1>
          <p className="text-sm opacity-80 mt-1">
            Apne mahalle ki dukaan, ek click order — Mingora, Swat
          </p>
        </Link>
        <Link
          href="/admin"
          className="text-sm opacity-70 hover:opacity-100 underline whitespace-nowrap"
        >
          Vendor / Admin login
        </Link>
      </div>
    </header>
  );
}
