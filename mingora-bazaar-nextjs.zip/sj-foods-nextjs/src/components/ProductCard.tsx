"use client";

import { useState } from "react";
import type { Product } from "@/lib/firebase";

interface ProductCardProps {
  product: Product;
  onAdd: (product: Product, qty: number) => void;
}

export default function ProductCard({ product, onAdd }: ProductCardProps) {
  const [qty, setQty] = useState(1);

  return (
    <div className="border border-stone rounded-lg p-4 bg-white/60 flex flex-col gap-2">
      <div className="flex items-start justify-between">
        <h3 className="font-display font-bold text-lg leading-tight">
          {product.name}
        </h3>
        {!product.inStock && (
          <span className="text-xs text-terracotta font-semibold">
            Stock khatam
          </span>
        )}
      </div>
      <p className="text-terracotta font-bold">
        Rs.{product.price}{" "}
        <span className="text-stone font-normal text-sm">/ {product.unit}</span>
      </p>

      {product.inStock && (
        <div className="flex items-center gap-3 mt-2">
          <div className="flex items-center border border-stone rounded-lg">
            <button
              className="px-3 py-1 text-lg"
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              aria-label="Kam karein"
            >
              −
            </button>
            <span className="px-2">{qty}</span>
            <button
              className="px-3 py-1 text-lg"
              onClick={() => setQty((q) => q + 1)}
              aria-label="Zyada karein"
            >
              +
            </button>
          </div>
          <button
            className="btn-primary text-sm py-2 px-4"
            onClick={() => onAdd(product, qty)}
          >
            Cart mein daalein
          </button>
        </div>
      )}
    </div>
  );
}
