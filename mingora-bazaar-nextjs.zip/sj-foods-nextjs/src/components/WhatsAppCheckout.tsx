"use client";

import { useState } from "react";
import type { CartItem, Vendor } from "@/lib/firebase";
import { pushOrder } from "@/lib/firebase";
import { buildWhatsAppLink, cartTotal } from "@/lib/whatsapp";

interface WhatsAppCheckoutProps {
  vendor: Vendor;
  cart: CartItem[];
  onUpdateQty: (productId: string, qty: number) => void;
  onClose: () => void;
  onOrderPlaced: () => void;
}

export default function WhatsAppCheckout({
  vendor,
  cart,
  onUpdateQty,
  onClose,
  onOrderPlaced,
}: WhatsAppCheckoutProps) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [area, setArea] = useState("");
  const [notes, setNotes] = useState("");
  const [sending, setSending] = useState(false);

  const total = cartTotal(cart);

  async function handleCheckout() {
    if (!name || !phone || !area || cart.length === 0) return;
    setSending(true);
    const customer = { name, phone, area, notes };

    try {
      await pushOrder({
        vendorId: vendor.id,
        vendorName: vendor.name,
        customer: name,
        phone,
        area,
        notes,
        items: cart,
        total,
      });
      const waLink = buildWhatsAppLink(vendor, customer, cart);
      window.open(waLink, "_blank");
      onOrderPlaced();
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50">
      <div className="bg-paper w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl p-6 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold">Aap ka order</h2>
          <button onClick={onClose} className="text-2xl leading-none" aria-label="Band karein">
            &times;
          </button>
        </div>

        <div className="space-y-3 mb-4">
          {cart.map((item) => (
            <div key={item.id} className="flex items-center justify-between text-sm">
              <span>
                {item.name} <span className="text-stone">({item.unit})</span>
              </span>
              <div className="flex items-center gap-2">
                <button onClick={() => onUpdateQty(item.id, item.qty - 1)}>−</button>
                <span>{item.qty}</span>
                <button onClick={() => onUpdateQty(item.id, item.qty + 1)}>+</button>
                <span className="w-16 text-right font-semibold">
                  Rs.{item.price * item.qty}
                </span>
              </div>
            </div>
          ))}
          {cart.length === 0 && (
            <p className="text-stone text-sm">Cart khali hai — pehle kuch items chunein.</p>
          )}
        </div>

        <p className="text-right font-semibold mb-4">Total: Rs.{total}</p>

        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            type="text"
            placeholder="Aap ka naam"
            className="w-full border border-stone rounded-lg px-3 py-2"
          />
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            type="tel"
            placeholder="Phone number"
            className="w-full border border-stone rounded-lg px-3 py-2"
          />
          <input
            value={area}
            onChange={(e) => setArea(e.target.value)}
            type="text"
            placeholder="Area / Mahalla"
            className="w-full border border-stone rounded-lg px-3 py-2"
          />
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Koi note (optional)"
            rows={2}
            className="w-full border border-stone rounded-lg px-3 py-2"
          />
        </div>

        <button
          onClick={handleCheckout}
          disabled={sending || cart.length === 0}
          className="btn-whatsapp w-full mt-5 disabled:opacity-50"
        >
          {sending ? "Bhej rahe hain..." : "WhatsApp par order bhejein"}
        </button>
      </div>
    </div>
  );
}
