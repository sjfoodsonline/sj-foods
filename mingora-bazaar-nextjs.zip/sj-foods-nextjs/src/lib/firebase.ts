import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getDatabase,
  ref,
  get,
  set,
  push,
  update,
  remove,
} from "firebase/database";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const db = getDatabase(app);

/* ============================================================
   Types — mirrors the Realtime Database shape:

   vendors/<id>/        { name, slug, category, phone, whatsapp,
                           area, description, status, products/ }
   vendors/<id>/products/<id>/ { name, price, unit, category, inStock }
   categories/<id>/     { name, icon }
   orders/<id>/         { vendorId, vendorName, customer, phone,
                           area, notes, items, total, status, createdAt }
   ============================================================ */

export type VendorStatus = "pending" | "approved" | "rejected";

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string; // e.g. "kg", "dozen", "piece", "litre"
  category?: string;
  inStock: boolean;
}

export interface Vendor {
  id: string;
  name: string;
  slug: string;
  category: string;
  phone: string;
  whatsapp?: string;
  area?: string;
  description?: string;
  status: VendorStatus;
  products?: Record<string, Omit<Product, "id">>;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
}

export interface CartItem {
  id: string;
  name: string;
  price: number;
  unit: string;
  qty: number;
}

export interface Order {
  vendorId: string;
  vendorName: string;
  customer: string;
  phone: string;
  area: string;
  notes?: string;
  items: CartItem[];
  total: number;
  status: "new" | "confirmed" | "delivered" | "cancelled";
  createdAt: number;
}

/* ------------------------------------------------------------ */

function toArray<T>(snapVal: Record<string, any> | null): (T & { id: string })[] {
  if (!snapVal) return [];
  return Object.entries(snapVal).map(([id, val]) => ({ id, ...(val as T) }));
}

export async function fetchApprovedVendors(): Promise<Vendor[]> {
  const snap = await get(ref(db, "vendors"));
  const vendors = toArray<Omit<Vendor, "id">>(snap.val());
  return vendors.filter((v) => v.status === "approved");
}

export async function fetchAllVendors(): Promise<Vendor[]> {
  const snap = await get(ref(db, "vendors"));
  return toArray<Omit<Vendor, "id">>(snap.val());
}

export async function fetchVendorBySlug(slug: string): Promise<Vendor | null> {
  const all = await fetchAllVendors();
  return all.find((v) => v.slug === slug) ?? null;
}

export async function fetchVendorProducts(vendorId: string): Promise<Product[]> {
  const snap = await get(ref(db, `vendors/${vendorId}/products`));
  return toArray<Omit<Product, "id">>(snap.val());
}

export async function fetchCategories(): Promise<Category[]> {
  const snap = await get(ref(db, "categories"));
  return toArray<Omit<Category, "id">>(snap.val());
}

/* ---- Admin writes (Approve/Reject + Categories + Pricing + Units) ---- */

export async function setVendorStatus(vendorId: string, status: VendorStatus) {
  await update(ref(db, `vendors/${vendorId}`), { status });
}

export async function addCategory(name: string, icon: string) {
  await push(ref(db, "categories"), { name, icon });
}

export async function deleteCategory(categoryId: string) {
  await remove(ref(db, `categories/${categoryId}`));
}

export async function upsertProduct(
  vendorId: string,
  productId: string | null,
  product: Omit<Product, "id">
) {
  const id = productId ?? push(ref(db, `vendors/${vendorId}/products`)).key!;
  await set(ref(db, `vendors/${vendorId}/products/${id}`), product);
}

export async function deleteProduct(vendorId: string, productId: string) {
  await remove(ref(db, `vendors/${vendorId}/products/${productId}`));
}

export async function pushOrder(order: Omit<Order, "createdAt" | "status">) {
  const orderRef = push(ref(db, "orders"));
  const fullOrder: Order = { ...order, status: "new", createdAt: Date.now() };
  await set(orderRef, fullOrder);
  return orderRef.key as string;
}

export async function fetchOrders(): Promise<(Order & { id: string })[]> {
  const snap = await get(ref(db, "orders"));
  return toArray<Order>(snap.val());
}
