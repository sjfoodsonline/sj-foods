import type { CartItem, Vendor } from "./firebase";

export interface Customer {
  name: string;
  phone: string;
  area: string;
  notes?: string;
}

export function cartTotal(cart: CartItem[]): number {
  return cart.reduce((sum, i) => sum + i.price * i.qty, 0);
}

/**
 * Builds the order message exactly as the vendor will read it on WhatsApp.
 */
export function buildWhatsAppMessage(
  vendor: Vendor,
  customer: Customer,
  cart: CartItem[]
): string {
  const lines: string[] = [];
  lines.push(`Naya order — ${vendor.name}`);
  lines.push("");
  cart.forEach((i) => {
    lines.push(`• ${i.name} x${i.qty} ${i.unit} — Rs.${i.price * i.qty}`);
  });
  lines.push("");
  lines.push(`Total: Rs.${cartTotal(cart)}`);
  lines.push("");
  lines.push(`Naam: ${customer.name}`);
  lines.push(`Phone: ${customer.phone}`);
  lines.push(`Area: ${customer.area}`);
  if (customer.notes) lines.push(`Note: ${customer.notes}`);
  return lines.join("\n");
}

/**
 * Builds a wa.me deep link that opens WhatsApp with the order pre-filled.
 */
export function buildWhatsAppLink(
  vendor: Vendor,
  customer: Customer,
  cart: CartItem[]
): string {
  const waNumber = (vendor.whatsapp || vendor.phone || "").replace(/[^0-9]/g, "");
  const message = buildWhatsAppMessage(vendor, customer, cart);
  return `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`;
}
